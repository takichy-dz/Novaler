#!/bin/bash

STB_IMAGE=$(cut /etc/opkg/all-feed.conf -d'-' -f1 | awk '{ print $2 }')

if [ $STB_IMAGE = 'pure2' ]; then
    update-rc.d -f softcam remove
    sleep 1
    unlink /etc/init.d/softcam
    sleep 1
    ln -sf /etc/init.d/softcam.None /etc/init.d/softcam
    update-rc.d softcam defaults
    if [ -e /etc/init.d/softcam.SupCam ]; then
        rm -rf /etc/init.d/softcam.SupCam
    fi
   	update-rc.d -f novacam* remove
    sleep 1
    unlink /etc/init.d/novacam*
	  sleep 1
    if [ -e /usr/camscript/ ]; then
    rm -rf /usr/camscript/
    fi
    if [ -e /usr/emu_scripts/ ]; then
    rm -rf /usr/emu_scripts/
    fi
    if [ -e /usr/script/Novacam-Premium_cam.sh ]; then
    rm -rf /usr/script/Novacam-Premium_cam.sh
    rm -rf /usr/script/Novacam-Supreme_cam.sh
    rm -rf /usr/script/Supcam_Novacam-Premium-cam.sh
    rm -rf /usr/script/Supcam_Novacam-Supreme-cam.sh
    fi
    if [ -e /etc/init.d/softcam.Novacam-Premium ]; then
    rm -rf /etc/init.d/softcam.Novacam-Premium
	  rm -rf /etc/init.d/softcam.Novacam-Supreme
	  rm -rf /etc/init.d/softcam.Supcam-Novacam-Premium
	  rm -rf /etc/init.d/softcam.Supcam-Novacam-Supreme
    fi
fi
if [ -e /usr/local/etc/oscam.dvbapi ]; then
rm -rf  /usr/local/etc/oscam.dvbapi
sleep 1
wget -qO /usr/local/etc/oscam.dvbapi https://raw.githubusercontent.com/takichy-dz/Novaler/main/oscam.dvbapi
fi
if [ -e /etc/RELOAD.sh ]; then
    rm -rf /etc/RELOAD.sh
	rm -rf /etc/SUPAUTO.sh
fi

sed -i '/RELOAD/d' /etc/cron/crontabs/root
sed -i '/SUPAUTO/d' /etc/cron/crontabs/root
