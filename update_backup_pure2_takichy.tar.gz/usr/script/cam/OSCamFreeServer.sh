#!/bin/bash
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"

IFS='/'
read -ra Binary <<<"$(find /usr/bin/cam | grep -Fi OSCam)"

OSD="OSCamFreeServer"
BINARY="${Binary[4]}"
PID=$(pidof "$BINARY")
Action=$1

cam_clean() {
	rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

cam_handle() {
	if test -z "${PID}"; then
		cam_up
	else
		cam_down
	fi
}

cam_down() {
	killall -9 "${BINARY}"
	sleep 2
	cam_clean
}

cam_up() {
	cam_clean
	/usr/bin/cam/"${BINARY}" --config-dir /etc/tuxbox/config/freeserver --daemon --pidfile /tmp/"${BINARY}".pid --restart 2 --utf8 2 | grep -v "UTF-8 mode"
}

if test "$Action" = "cam_startup"; then
	if test -z "${PID}"; then
		cam_down
		cam_up
	else
		echo "$OSD already running, exiting..."
	fi
elif test "$Action" = "cam_res"; then
	cam_down
	cam_up
elif test "$Action" = "cam_down"; then
	cam_down
elif test "$Action" = "cam_up"; then
	cam_up
else
	cam_handle
fi

exit 0
